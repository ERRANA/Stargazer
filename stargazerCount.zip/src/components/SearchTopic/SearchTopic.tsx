import { useCallback, useRef, useState } from "react";
import { useTopics } from "../../hooks/useTopics.js";
import Item from "../../interfaces/item.js";
import Topic from "../Topic/Topic";
import classes from "./SearchTopic.module.css";

const SearchTopic = () => {
  const [search, setSearch] = useState("");
  const { topic } = useTopics(search);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Click handler for search button
  const handleClickSearch = useCallback(() => {
    setSearch(searchInputRef.current?.value || "");
  }, []);

  return (
    <>
      <div className={classes.inputContainer}>
        {/* Search input with button */}
        <input
          type="text"
          defaultValue=""
          ref={searchInputRef}
          placeholder={"Enter a topic"}
          className={classes.inputCls}
        />
        <button onClick={handleClickSearch} className={classes.btn}>
          Search
        </button>
      </div>
      <div className={classes.inputContainer}>
        <div>
          {search && topic.length > 0 ? (
            <p>
              {/* if no topics found then print search query */}
              {`Topics related to `}
              <b>{search}</b>
            </p>
          ) : (
            <p>
              {/* if no topics found then print 'No results' */}
              <b>{`No results`}</b>
            </p>
          )}
          {/* if topics are present, Loop through them and print */}
          {topic &&
            topic?.map((item: Item) => (
              <Topic key={item.id} item={item} setSearch={setSearch} />
            ))}
        </div>
      </div>
    </>
  );
};

export default SearchTopic;
