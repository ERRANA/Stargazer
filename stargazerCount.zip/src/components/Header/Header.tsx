import classes from './Header.module.css';

function Header() {
    return (
        <h1 className={classes.header}>
            GitHub Topic Explorer StarGazer {`⭐`}
        </h1>
    );
}

export default Header;