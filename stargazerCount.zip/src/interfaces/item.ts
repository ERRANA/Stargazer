export default interface Item {
  id: string;
  name: string;
  stargazerCount: number;
}